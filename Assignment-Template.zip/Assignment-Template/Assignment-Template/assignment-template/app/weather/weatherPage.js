"use client";

import React, { useState, useEffect } from "react";
import { useUserAuth } from "../auth-context";
import Link from "next/link";

export default function Weather({ city = "Calgary" }) {
  const [weather, setWeather] = useState(null);
  const { user, firebaseSignOut } = useUserAuth();

  // Function to fetch weather data from the OpenWeatherMap API
  const fetchWeather = async () => {
    const apiKey = process.env.NEXT_PUBLIC_OPENWEATHERMAP_API_KEY;
    const city = "Calgary";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;
  
    try {
      console.log(`Fetching weather data for ${city}`);
      const response = await fetch(url);
      const data = await response.json();
      
      console.log("Response from the weather API:", data);
  
      if (response.ok) {
        setWeather(data);
      } else {
        throw new Error(`API call failed with status: ${response.status}`);
      }
    } catch (error) {
      console.error("Error fetching weather data:", error);
    }
  };
  
  // Effect to fetch weather when the component mounts or when the user or city props change
  useEffect(() => {
    if (user) fetchWeather();
  }, [user, city]);

  return (
<main className="min-h-screen bg-blue-50 flex flex-col justify-center items-center p-6">
  <h1 className="text-3xl font-bold mb-6 text-gray-800">Weather in Calgary</h1>
  {user ? (
    <>
      {weather ? (
        <div className="bg-white shadow-lg rounded-lg p-6 text-center">
          <p className="text-xl font-semibold mb-2">Temperature: {weather.main?.temp}°C</p>
          <p className="text-gray-600 mb-4">Condition: {weather.weather?.[0]?.description}</p>
          <img
            src={`http://openweathermap.org/img/wn/${weather.weather?.[0]?.icon}.png`}
            alt="weather icon"
            className="mx-auto"
          />
        </div>
      ) : (
        <p>Loading weather data...</p>
      )}
      <button 
        onClick={firebaseSignOut}
        className="mt-8 bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out focus:outline-none focus:shadow-outline"
      >
        Logout
      </button>
    </>
  ) : (
    <>
      <p className="mb-4 text-lg text-gray-700">Please log in to see the weather information.</p>
      <Link href="/">
        <a className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-lg transition duration-300 ease-in-out focus:outline-none focus:shadow-outline">Home</a>
      </Link>
    </>
  )}
</main>

  );
}












