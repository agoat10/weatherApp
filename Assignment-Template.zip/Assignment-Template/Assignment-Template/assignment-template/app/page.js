"use client";

import React from 'react';
import dynamic from 'next/dynamic';
import { useUserAuth } from "./auth-context";

const WeatherPageWithNoSSR = dynamic(() => import('./weather/weatherPage'), { ssr: false });

export default function Page() {
  const { user, gitHubSignIn } = useUserAuth();

  const weatherCity = "Calgary";

  return (
      <div className="min-h-screen flex flex-col justify-center items-center bg-blue-50 p-6">
          {!user && (
              <>
                <h1 className="text-4xl text-center font-bold text-gray-800 mb-6">Welcome to the Weather App!</h1>
                <button onClick={gitHubSignIn} className="text-lg bg-black hover:bg-gray-900 text-white font-bold py-2 px-4 rounded-full transition duration-300 ease-in-out shadow-lg">
                  Sign In with GitHub
                </button>
              </>
          )}
          {user && (
              <>
                  <WeatherPageWithNoSSR city={weatherCity} />
              </>
          )}
      </div>
  );
}
